# Deploying this frontend to Vercel or Netlify

First, set the API URL as an environment variable in whichever host you use:

- `VITE_API_URL` = `https://<your-backend-url>/api`
- `VITE_UPLOADS_URL` = `https://<your-backend-url>`

## Option A — Vercel

**Via CLI (no GitHub needed):**
```bash
npm install -g vercel
cd frontend
vercel
```
Follow the prompts (framework preset: Vite). Set the two env vars above
either when prompted or later in the Vercel dashboard → Settings →
Environment Variables, then redeploy.

**Via GitHub:** push this folder to a repo, then import it on vercel.com —
it auto-detects the Vite build. `vercel.json` (included) handles client-side
routing so refreshing `/song/123` works correctly.

## Option B — Netlify

**Via drag-and-drop (no GitHub needed):**
```bash
cd frontend
npm install
npm run build          # outputs to dist/
```
Then drag the `dist` folder onto netlify.com's deploy page. Set the env vars
in Site settings → Environment variables and trigger a redeploy so the build
picks them up (drag-and-drop deploys skip the build step, so for env vars to
take effect you'll want the CLI or Git-based deploy instead).

**Via CLI:**
```bash
npm install -g netlify-cli
cd frontend
netlify deploy --prod
```

**Via GitHub:** push this folder to a repo, import on netlify.com — the
included `netlify.toml` sets the build command, publish directory, and the
redirect rule needed for client-side routing.
