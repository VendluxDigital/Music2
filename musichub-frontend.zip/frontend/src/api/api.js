import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
export const UPLOADS_URL = import.meta.env.VITE_UPLOADS_URL || "http://localhost:5000";

const api = axios.create({ baseURL: API_URL });

// Attach the admin JWT (if present) to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("musichub_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Helper to build an absolute URL for a stored cover/audio path like "/uploads/covers/xyz.jpg"
export const assetUrl = (path) => {
  if (!path) return "";
  return path.startsWith("http") ? path : `${UPLOADS_URL}${path}`;
};

export default api;
