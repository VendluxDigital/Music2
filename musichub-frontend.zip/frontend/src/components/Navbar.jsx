import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import SearchBar from "./SearchBar.jsx";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const links = [
    { to: "/", label: "Home" },
    { to: "/latest", label: "Latest" },
    { to: "/about", label: "About" },
    { to: "/contact", label: "Contact" },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-white/5 bg-ink/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3 sm:px-6">
        <Link to="/" className="flex items-center gap-2 shrink-0">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-amber to-amber2 text-ink font-display font-bold">
            M
          </span>
          <span className="font-display text-lg font-semibold tracking-tight">
            Music<span className="text-amber">Hub</span>
          </span>
        </Link>

        <div className="hidden flex-1 md:block">
          <SearchBar
            compact
            onSearch={(q) => navigate(`/latest?q=${encodeURIComponent(q)}`)}
          />
        </div>

        <nav className="ml-auto hidden items-center gap-6 md:flex">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="text-sm text-mist transition hover:text-white"
            >
              {l.label}
            </Link>
          ))}
          <Link
            to="/admin/login"
            className="rounded-full border border-white/10 px-4 py-1.5 text-sm text-white transition hover:border-amber hover:text-amber"
          >
            Admin
          </Link>
        </nav>

        <button
          aria-label="Toggle menu"
          className="ml-auto rounded-md p-2 text-white md:hidden"
          onClick={() => setOpen((o) => !o)}
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M4 6h16M4 12h16M4 18h16" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      {open && (
        <div className="border-t border-white/5 px-4 pb-4 pt-3 md:hidden">
          <SearchBar
            onSearch={(q) => {
              navigate(`/latest?q=${encodeURIComponent(q)}`);
              setOpen(false);
            }}
          />
          <div className="mt-4 flex flex-col gap-3">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="text-mist hover:text-white"
                onClick={() => setOpen(false)}
              >
                {l.label}
              </Link>
            ))}
            <Link
              to="/admin/login"
              className="text-amber"
              onClick={() => setOpen(false)}
            >
              Admin login
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
