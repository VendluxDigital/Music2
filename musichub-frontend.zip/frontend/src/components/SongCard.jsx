import React from "react";
import { Link } from "react-router-dom";
import { assetUrl } from "../api/api.js";

export default function SongCard({ song }) {
  return (
    <Link
      to={`/song/${song._id}`}
      className="group block overflow-hidden rounded-2xl bg-surface transition hover:bg-surface2"
    >
      <div className="aspect-square overflow-hidden">
        <img
          src={assetUrl(song.coverImage)}
          alt={`${song.title} cover art`}
          loading="lazy"
          className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
        />
      </div>
      <div className="p-3">
        <h3 className="truncate font-display text-sm font-semibold text-white">
          {song.title}
        </h3>
        <p className="truncate text-xs text-mist">{song.artist}</p>
      </div>
    </Link>
  );
}
