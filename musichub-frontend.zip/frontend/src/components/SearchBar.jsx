import React, { useState } from "react";

export default function SearchBar({ onSearch, compact = false, initialValue = "" }) {
  const [value, setValue] = useState(initialValue);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch?.(value.trim());
  };

  return (
    <form onSubmit={handleSubmit} className="relative w-full">
      <input
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Search songs, artists, albums…"
        aria-label="Search songs"
        className={`w-full rounded-full border border-white/10 bg-surface px-5 text-sm text-white placeholder-mist/70 outline-none transition focus:border-amber ${
          compact ? "py-2" : "py-3"
        }`}
      />
      <button
        type="submit"
        aria-label="Search"
        className="absolute right-1.5 top-1/2 grid -translate-y-1/2 place-items-center rounded-full bg-amber p-2 text-ink transition hover:bg-amber2"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
          <circle cx="11" cy="11" r="7" />
          <path d="M21 21l-4.3-4.3" strokeLinecap="round" />
        </svg>
      </button>
    </form>
  );
}
