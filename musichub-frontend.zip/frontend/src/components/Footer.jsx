import React from "react";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-white/5 bg-surface/40">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-gradient-to-br from-amber to-amber2 text-ink font-display font-bold">
              M
            </span>
            <span className="font-display text-base font-semibold">
              Music<span className="text-amber">Hub</span>
            </span>
          </div>
          <p className="mt-3 max-w-xs text-sm text-mist">
            A small, fast home for the songs you keep coming back to.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white">Explore</h4>
          <ul className="mt-3 space-y-2 text-sm text-mist">
            <li><Link to="/" className="hover:text-white">Home</Link></li>
            <li><Link to="/latest" className="hover:text-white">Latest songs</Link></li>
            <li><Link to="/about" className="hover:text-white">About</Link></li>
            <li><Link to="/contact" className="hover:text-white">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white">Rights</h4>
          <p className="mt-3 text-sm text-mist">
            All songs are uploaded by administrators who confirm they hold
            distribution rights. See our
            {" "}
            <Link to="/contact" className="text-amber hover:text-amber2">
              contact page
            </Link>{" "}
            for takedown requests.
          </p>
        </div>
      </div>
      <div className="border-t border-white/5 py-4 text-center text-xs text-mist">
        © {new Date().getFullYear()} MusicHub. All rights reserved.
      </div>
    </footer>
  );
}
