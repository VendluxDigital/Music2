import React, { createContext, useContext, useState, useCallback } from "react";
import api from "../api/api.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem("musichub_token"));
  const [admin, setAdmin] = useState(() => {
    const stored = localStorage.getItem("musichub_admin");
    return stored ? JSON.parse(stored) : null;
  });

  const login = useCallback(async (username, password) => {
    const { data } = await api.post("/auth/login", { username, password });
    localStorage.setItem("musichub_token", data.token);
    localStorage.setItem("musichub_admin", JSON.stringify(data.admin));
    setToken(data.token);
    setAdmin(data.admin);
    return data;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem("musichub_token");
    localStorage.removeItem("musichub_admin");
    setToken(null);
    setAdmin(null);
  }, []);

  const value = { token, admin, isAuthenticated: !!token, login, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
