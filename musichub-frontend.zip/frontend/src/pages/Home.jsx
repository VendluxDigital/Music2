import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api.js";
import SearchBar from "../components/SearchBar.jsx";
import SongCard from "../components/SongCard.jsx";

export default function Home() {
  const [latest, setLatest] = useState([]);
  const [trending, setTrending] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const [latestRes, trendingRes] = await Promise.all([
          api.get("/songs/latest?limit=8"),
          api.get("/songs/trending?limit=8"),
        ]);
        if (!mounted) return;
        setLatest(latestRes.data.songs);
        setTrending(trendingRes.data.songs);
      } catch (err) {
        console.error(err);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-white/5 bg-gradient-to-b from-surface to-ink">
        <div className="mx-auto max-w-6xl px-4 py-16 text-center sm:px-6 sm:py-24">
          <p className="font-display text-sm uppercase tracking-[0.3em] text-amber">
            Now spinning
          </p>
          <h1 className="mx-auto mt-4 max-w-2xl font-display text-4xl font-semibold leading-tight sm:text-5xl">
            Find your next favorite track
          </h1>
          <p className="mx-auto mt-4 max-w-md text-mist">
            A small, fast library of songs you can stream, share, and download —
            uploaded and curated by our team.
          </p>
          <div className="mx-auto mt-8 max-w-xl">
            <SearchBar onSearch={(q) => navigate(`/latest?q=${encodeURIComponent(q)}`)} />
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <SongSection title="Latest songs" songs={latest} loading={loading} viewAllTo="/latest" />
        <SongSection title="Trending now" songs={trending} loading={loading} viewAllTo="/latest" />
      </div>
    </div>
  );
}

function SongSection({ title, songs, loading, viewAllTo }) {
  const navigate = useNavigate();
  return (
    <section className="mb-14">
      <div className="mb-5 flex items-center justify-between">
        <h2 className="font-display text-xl font-semibold">{title}</h2>
        <button
          onClick={() => navigate(viewAllTo)}
          className="text-sm text-amber hover:text-amber2"
        >
          View all
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="aspect-square animate-pulse rounded-2xl bg-surface" />
          ))}
        </div>
      ) : songs.length === 0 ? (
        <p className="text-mist">No songs yet — check back soon.</p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
          {songs.map((song) => (
            <SongCard key={song._id} song={song} />
          ))}
        </div>
      )}
    </section>
  );
}
