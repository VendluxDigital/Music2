import React, { useEffect, useState } from "react";
import api, { assetUrl } from "../api/api.js";
import { useAuth } from "../context/AuthContext.jsx";

const emptyForm = {
  title: "",
  artist: "",
  album: "",
  genre: "",
  rightsConfirmed: false,
  audio: null,
  cover: null,
};

export default function AdminDashboard() {
  const { admin, logout } = useAuth();
  const [songs, setSongs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const loadSongs = async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/songs?limit=100");
      setSongs(data.songs);
    } catch (err) {
      setError("Could not load songs.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSongs();
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    if (type === "checkbox") {
      setForm((f) => ({ ...f, [name]: checked }));
    } else if (type === "file") {
      setForm((f) => ({ ...f, [name]: files[0] }));
    } else {
      setForm((f) => ({ ...f, [name]: value }));
    }
  };

  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
  };

  const startEdit = (song) => {
    setEditingId(song._id);
    setForm({
      title: song.title,
      artist: song.artist,
      album: song.album || "",
      genre: song.genre || "",
      rightsConfirmed: true,
      audio: null,
      cover: null,
    });
    setMessage("");
    setError("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    if (!editingId && (!form.audio || !form.cover)) {
      setError("An audio file and a cover image are both required for a new song.");
      return;
    }
    if (!form.rightsConfirmed) {
      setError("You must confirm you have permission to distribute this song.");
      return;
    }

    const payload = new FormData();
    payload.append("title", form.title);
    payload.append("artist", form.artist);
    payload.append("album", form.album);
    payload.append("genre", form.genre);
    payload.append("rightsConfirmed", "true");
    if (form.audio) payload.append("audio", form.audio);
    if (form.cover) payload.append("cover", form.cover);

    setSaving(true);
    try {
      if (editingId) {
        await api.put(`/songs/${editingId}`, payload, {
          headers: { "Content-Type": "multipart/form-data" },
        });
        setMessage("Song updated.");
      } else {
        await api.post("/songs", payload, {
          headers: { "Content-Type": "multipart/form-data" },
        });
        setMessage("Song uploaded.");
      }
      resetForm();
      loadSongs();
    } catch (err) {
      setError(err.response?.data?.message || "Something went wrong. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this song permanently?")) return;
    try {
      await api.delete(`/songs/${id}`);
      setSongs((s) => s.filter((song) => song._id !== id));
    } catch (err) {
      setError("Could not delete song.");
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="font-display text-sm uppercase tracking-[0.3em] text-amber">
            Dashboard
          </p>
          <h1 className="mt-1 font-display text-2xl font-semibold sm:text-3xl">
            Welcome back{admin?.username ? `, ${admin.username}` : ""}
          </h1>
        </div>
        <button
          onClick={logout}
          className="rounded-full border border-white/10 px-4 py-2 text-sm text-mist transition hover:border-amber hover:text-amber"
        >
          Log out
        </button>
      </div>

      <div className="mt-10 grid gap-10 lg:grid-cols-[380px_1fr]">
        {/* Upload / edit form */}
        <div className="h-fit rounded-2xl bg-surface p-6">
          <h2 className="font-display text-lg font-semibold">
            {editingId ? "Edit song" : "Upload a song"}
          </h2>

          {message && (
            <p className="mt-3 rounded-lg bg-emerald-500/10 px-4 py-2 text-sm text-emerald-300">
              {message}
            </p>
          )}
          {error && (
            <p className="mt-3 rounded-lg bg-red-500/10 px-4 py-2 text-sm text-red-300">
              {error}
            </p>
          )}

          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            <Field label="Title">
              <input
                required
                name="title"
                value={form.title}
                onChange={handleChange}
                className="input"
              />
            </Field>
            <Field label="Artist">
              <input
                required
                name="artist"
                value={form.artist}
                onChange={handleChange}
                className="input"
              />
            </Field>
            <Field label="Album (optional)">
              <input name="album" value={form.album} onChange={handleChange} className="input" />
            </Field>
            <Field label="Genre (optional)">
              <input name="genre" value={form.genre} onChange={handleChange} className="input" />
            </Field>
            <Field label={`Audio file ${editingId ? "(leave blank to keep current)" : ""}`}>
              <input
                type="file"
                name="audio"
                accept="audio/*"
                onChange={handleChange}
                className="input file:mr-3 file:rounded-full file:border-0 file:bg-amber file:px-3 file:py-1.5 file:text-ink"
              />
            </Field>
            <Field label={`Cover image ${editingId ? "(leave blank to keep current)" : ""}`}>
              <input
                type="file"
                name="cover"
                accept="image/*"
                onChange={handleChange}
                className="input file:mr-3 file:rounded-full file:border-0 file:bg-amber file:px-3 file:py-1.5 file:text-ink"
              />
            </Field>

            <label className="flex items-start gap-2 text-sm text-mist">
              <input
                type="checkbox"
                name="rightsConfirmed"
                checked={form.rightsConfirmed}
                onChange={handleChange}
                className="mt-1 accent-amber"
              />
              I confirm I have the legal right to upload and distribute this song.
            </label>

            <div className="flex gap-3">
              <button
                type="submit"
                disabled={saving}
                className="flex-1 rounded-full bg-amber px-5 py-3 font-medium text-ink transition hover:bg-amber2 disabled:opacity-60"
              >
                {saving ? "Saving…" : editingId ? "Save changes" : "Upload song"}
              </button>
              {editingId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="rounded-full border border-white/10 px-5 py-3 text-sm text-mist hover:text-white"
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Song list */}
        <div>
          <h2 className="font-display text-lg font-semibold">
            All songs {!loading && `(${songs.length})`}
          </h2>

          {loading ? (
            <p className="mt-4 text-mist">Loading…</p>
          ) : songs.length === 0 ? (
            <p className="mt-4 text-mist">No songs uploaded yet.</p>
          ) : (
            <ul className="mt-4 divide-y divide-white/5">
              {songs.map((song) => (
                <li key={song._id} className="flex items-center gap-4 py-3">
                  <img
                    src={assetUrl(song.coverImage)}
                    alt=""
                    className="h-12 w-12 rounded-lg object-cover"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium text-white">{song.title}</p>
                    <p className="truncate text-sm text-mist">{song.artist}</p>
                  </div>
                  <span className="hidden text-xs text-mist sm:block">
                    {song.plays} plays · {song.downloads} downloads
                  </span>
                  <button
                    onClick={() => startEdit(song)}
                    className="rounded-full border border-white/10 px-3 py-1.5 text-xs text-mist hover:border-amber hover:text-amber"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(song._id)}
                    className="rounded-full border border-white/10 px-3 py-1.5 text-xs text-mist hover:border-red-400 hover:text-red-400"
                  >
                    Delete
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="mb-1.5 block text-sm text-mist">{label}</label>
      {children}
    </div>
  );
}
