import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const from = location.state?.from?.pathname || "/admin/dashboard";

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(username, password);
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || "Login failed. Check your credentials.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-sm flex-col justify-center px-4 py-14 sm:px-6">
      <p className="text-center font-display text-sm uppercase tracking-[0.3em] text-amber">
        Admin
      </p>
      <h1 className="mt-2 text-center font-display text-2xl font-semibold">
        Sign in to manage songs
      </h1>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        {error && (
          <p className="rounded-lg bg-red-500/10 px-4 py-2 text-sm text-red-300">{error}</p>
        )}
        <div>
          <label className="mb-1.5 block text-sm text-mist">Username</label>
          <input
            required
            autoFocus
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full rounded-xl border border-white/10 bg-surface px-4 py-2.5 outline-none focus:border-amber"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-sm text-mist">Password</label>
          <input
            required
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-xl border border-white/10 bg-surface px-4 py-2.5 outline-none focus:border-amber"
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-full bg-amber px-5 py-3 font-medium text-ink transition hover:bg-amber2 disabled:opacity-60"
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
      </form>
    </div>
  );
}
