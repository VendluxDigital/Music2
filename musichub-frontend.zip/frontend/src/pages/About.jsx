import React from "react";

export default function About() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-14 sm:px-6">
      <p className="font-display text-sm uppercase tracking-[0.3em] text-amber">About</p>
      <h1 className="mt-3 font-display text-3xl font-semibold sm:text-4xl">
        Built for people who just want to listen
      </h1>
      <div className="mt-6 space-y-4 text-mist">
        <p>
          MusicHub is a small, fast, no-frills home for streaming songs. No
          clutter, no autoplay ads — just a search bar, a library, and a
          player that gets out of your way.
        </p>
        <p>
          Every track on this site is uploaded by our admin team, who confirm
          they hold the rights to distribute it before it goes live. If
          you're a rights holder with a concern about a specific upload,
          please reach out through our contact page and we'll respond
          promptly.
        </p>
        <p>
          The site is built with React and Tailwind CSS on the front end, and
          Express, MongoDB, and JWT authentication on the back end — kept
          intentionally lightweight so pages load fast on any connection.
        </p>
      </div>
    </div>
  );
}
