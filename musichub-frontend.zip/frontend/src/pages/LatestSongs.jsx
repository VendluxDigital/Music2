import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import api from "../api/api.js";
import SearchBar from "../components/SearchBar.jsx";
import SongCard from "../components/SongCard.jsx";

export default function LatestSongs() {
  const [searchParams, setSearchParams] = useSearchParams();
  const q = searchParams.get("q") || "";
  const [songs, setSongs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    (async () => {
      try {
        const endpoint = q
          ? `/songs/search?q=${encodeURIComponent(q)}`
          : `/songs?page=${page}&limit=20`;
        const { data } = await api.get(endpoint);
        if (!mounted) return;
        setSongs(data.songs);
        setPages(data.pages || 1);
      } catch (err) {
        console.error(err);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [q, page]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <h1 className="font-display text-2xl font-semibold sm:text-3xl">
        {q ? `Results for "${q}"` : "Latest songs"}
      </h1>

      <div className="mt-6 max-w-xl">
        <SearchBar
          initialValue={q}
          onSearch={(value) =>
            setSearchParams(value ? { q: value } : {})
          }
        />
      </div>

      <div className="mt-8">
        {loading ? (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-5">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="aspect-square animate-pulse rounded-2xl bg-surface" />
            ))}
          </div>
        ) : songs.length === 0 ? (
          <p className="text-mist">No songs found. Try a different search.</p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-5">
            {songs.map((song) => (
              <SongCard key={song._id} song={song} />
            ))}
          </div>
        )}
      </div>

      {!q && pages > 1 && (
        <div className="mt-8 flex justify-center gap-2">
          {Array.from({ length: pages }).map((_, i) => (
            <button
              key={i}
              onClick={() => setPage(i + 1)}
              className={`h-9 w-9 rounded-full text-sm transition ${
                page === i + 1
                  ? "bg-amber text-ink"
                  : "bg-surface text-mist hover:text-white"
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
