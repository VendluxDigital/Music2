import React, { useState } from "react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleChange = (e) =>
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    // This demo form doesn't wire up an email backend — hook this up to
    // your own mail service or a backend endpoint as needed.
    setSent(true);
  };

  return (
    <div className="mx-auto max-w-xl px-4 py-14 sm:px-6">
      <p className="font-display text-sm uppercase tracking-[0.3em] text-amber">Contact</p>
      <h1 className="mt-3 font-display text-3xl font-semibold sm:text-4xl">
        Get in touch
      </h1>
      <p className="mt-4 text-mist">
        Questions, feedback, or a takedown request? Send us a message below.
      </p>

      {sent ? (
        <div className="mt-8 rounded-2xl bg-surface p-6 text-center">
          <p className="text-white">Thanks — your message has been noted.</p>
          <p className="mt-1 text-sm text-mist">We'll get back to you soon.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="mt-8 space-y-4">
          <div>
            <label className="mb-1.5 block text-sm text-mist">Name</label>
            <input
              required
              name="name"
              value={form.name}
              onChange={handleChange}
              className="w-full rounded-xl border border-white/10 bg-surface px-4 py-2.5 outline-none focus:border-amber"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-sm text-mist">Email</label>
            <input
              required
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              className="w-full rounded-xl border border-white/10 bg-surface px-4 py-2.5 outline-none focus:border-amber"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-sm text-mist">Message</label>
            <textarea
              required
              name="message"
              rows={4}
              value={form.message}
              onChange={handleChange}
              className="w-full rounded-xl border border-white/10 bg-surface px-4 py-2.5 outline-none focus:border-amber"
            />
          </div>
          <button
            type="submit"
            className="w-full rounded-full bg-amber px-5 py-3 font-medium text-ink transition hover:bg-amber2"
          >
            Send message
          </button>
        </form>
      )}
    </div>
  );
}
