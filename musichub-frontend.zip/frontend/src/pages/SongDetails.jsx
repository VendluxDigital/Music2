import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api, { assetUrl } from "../api/api.js";
import AudioPlayer from "../components/AudioPlayer.jsx";
import SongCard from "../components/SongCard.jsx";

export default function SongDetails() {
  const { id } = useParams();
  const [song, setSong] = useState(null);
  const [related, setRelated] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    setError("");
    (async () => {
      try {
        const { data } = await api.get(`/songs/${id}`);
        if (!mounted) return;
        setSong(data.song);
        setRelated(data.related || []);
      } catch (err) {
        if (mounted) setError("This song could not be found.");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [id]);

  if (loading) {
    return <div className="mx-auto max-w-4xl px-4 py-16 text-center text-mist">Loading…</div>;
  }

  if (error || !song) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-16 text-center">
        <p className="text-mist">{error || "Song not found."}</p>
        <Link to="/latest" className="mt-4 inline-block text-amber hover:text-amber2">
          Browse all songs
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
      <div className="grid gap-8 md:grid-cols-[280px_1fr]">
        <div className="mx-auto w-56 shrink-0 overflow-hidden rounded-full shadow-glow md:w-full md:rounded-2xl">
          <img
            src={assetUrl(song.coverImage)}
            alt={`${song.title} cover art`}
            className="spin-slow h-full w-full object-cover md:animate-none"
          />
        </div>

        <div className="flex flex-col justify-center">
          <p className="font-display text-sm uppercase tracking-[0.25em] text-amber">
            Now playing
          </p>
          <h1 className="mt-2 font-display text-3xl font-semibold sm:text-4xl">
            {song.title}
          </h1>
          <p className="mt-1 text-lg text-mist">{song.artist}</p>
          {song.album && <p className="mt-1 text-sm text-mist">Album: {song.album}</p>}

          <div className="mt-6">
            <AudioPlayer src={assetUrl(song.audioFile)} />
          </div>

          <a
            href={`${api.defaults.baseURL}/songs/${song._id}/download`}
            className="mt-4 inline-flex w-fit items-center gap-2 rounded-full bg-white/5 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-white/10"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 3v12m0 0l-4-4m4 4l4-4M4 21h16" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Download
          </a>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-16">
          <h2 className="mb-5 font-display text-xl font-semibold">Related songs</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
            {related.map((s) => (
              <SongCard key={s._id} song={s} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
