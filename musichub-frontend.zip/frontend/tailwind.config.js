/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#151217",
        surface: "#1F1B23",
        surface2: "#2A2530",
        amber: "#E8A33D",
        amber2: "#C97C2C",
        mist: "#B7AFC2",
      },
      fontFamily: {
        display: ["'Fraunces'", "serif"],
        body: ["'Inter'", "sans-serif"],
      },
      boxShadow: {
        glow: "0 0 40px -10px rgba(232,163,61,0.35)",
      },
    },
  },
  plugins: [],
};
