// Run with: node scripts/createAdmin.js
// Creates (or resets the password for) the admin account defined in .env.
// Make sure you've already run `npx prisma db push` at least once so the
// Admin table exists in your Postgres/Neon database.
require("dotenv").config();
const bcrypt = require("bcryptjs");
const prisma = require("../lib/prisma");

(async () => {
  const username = process.env.ADMIN_USERNAME || "admin";
  const password = process.env.ADMIN_PASSWORD || "admin123";
  const hashed = await bcrypt.hash(password, 10);

  const existing = await prisma.admin.findUnique({ where: { username } });
  if (existing) {
    await prisma.admin.update({ where: { username }, data: { password: hashed } });
    console.log(`Password updated for existing admin "${username}"`);
  } else {
    await prisma.admin.create({ data: { username, password: hashed } });
    console.log(`Admin account created: "${username}"`);
  }

  await prisma.$disconnect();
  process.exit(0);
})().catch(async (err) => {
  console.error(err);
  await prisma.$disconnect();
  process.exit(1);
});
