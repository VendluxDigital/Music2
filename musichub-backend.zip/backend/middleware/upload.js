const multer = require("multer");
const path = require("path");
const fs = require("fs");

const SONGS_DIR = path.join(__dirname, "..", "uploads", "songs");
const COVERS_DIR = path.join(__dirname, "..", "uploads", "covers");
[SONGS_DIR, COVERS_DIR].forEach((dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (file.fieldname === "audio") cb(null, SONGS_DIR);
    else if (file.fieldname === "cover") cb(null, COVERS_DIR);
    else cb(new Error("Unexpected field"), null);
  },
  filename: (req, file, cb) => {
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `${unique}${path.extname(file.originalname)}`);
  },
});

const ALLOWED_AUDIO = [".mp3", ".wav", ".ogg", ".m4a", ".flac"];
const ALLOWED_IMAGE = [".jpg", ".jpeg", ".png", ".webp"];

const fileFilter = (req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase();
  if (file.fieldname === "audio" && !ALLOWED_AUDIO.includes(ext)) {
    return cb(new Error("Unsupported audio format"), false);
  }
  if (file.fieldname === "cover" && !ALLOWED_IMAGE.includes(ext)) {
    return cb(new Error("Unsupported image format"), false);
  }
  cb(null, true);
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 25 * 1024 * 1024 }, // 25MB per file
});

module.exports = upload;
