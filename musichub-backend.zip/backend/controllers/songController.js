const fs = require("fs");
const path = require("path");
const prisma = require("../lib/prisma");

const toPublicPath = (folder, filename) => `/uploads/${folder}/${filename}`;

// The frontend expects a Mongo-style "_id" field on every song object.
// This keeps the API response shape stable even though the database is
// now Postgres (where the primary key is a plain integer "id").
const withId = (song) => (song ? { ...song, _id: String(song.id) } : song);
const withIds = (songs) => songs.map(withId);

const parseId = (raw) => {
  const id = parseInt(raw, 10);
  return Number.isNaN(id) ? null : id;
};

// GET /api/songs?page=&limit=
exports.getAllSongs = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    const [songs, total] = await Promise.all([
      prisma.song.findMany({ orderBy: { createdAt: "desc" }, skip, take: limit }),
      prisma.song.count(),
    ]);

    res.json({ songs: withIds(songs), total, page, pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

// GET /api/songs/latest
exports.getLatestSongs = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 12;
    const songs = await prisma.song.findMany({ orderBy: { createdAt: "desc" }, take: limit });
    res.json({ songs: withIds(songs) });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

// GET /api/songs/trending
exports.getTrendingSongs = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 12;
    const songs = await prisma.song.findMany({
      orderBy: [{ plays: "desc" }, { createdAt: "desc" }],
      take: limit,
    });
    res.json({ songs: withIds(songs) });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

// GET /api/songs/search?q=
exports.searchSongs = async (req, res) => {
  try {
    const q = (req.query.q || "").trim();
    if (!q) return res.json({ songs: [] });

    const songs = await prisma.song.findMany({
      where: {
        OR: [
          { title: { contains: q, mode: "insensitive" } },
          { artist: { contains: q, mode: "insensitive" } },
          { album: { contains: q, mode: "insensitive" } },
          { genre: { contains: q, mode: "insensitive" } },
        ],
      },
      orderBy: { createdAt: "desc" },
      take: 30,
    });

    res.json({ songs: withIds(songs) });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

// GET /api/songs/:id
exports.getSongById = async (req, res) => {
  try {
    const id = parseId(req.params.id);
    if (id === null) return res.status(404).json({ message: "Song not found" });

    const song = await prisma.song.findUnique({ where: { id } });
    if (!song) return res.status(404).json({ message: "Song not found" });

    // increment play count (best-effort, non-blocking response)
    prisma.song.update({ where: { id }, data: { plays: { increment: 1 } } }).catch(() => {});

    const related = await prisma.song.findMany({
      where: {
        id: { not: id },
        OR: [{ artist: song.artist }, { genre: song.genre }],
      },
      take: 8,
    });

    res.json({ song: withId(song), related: withIds(related) });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

// POST /api/songs (admin only)
exports.createSong = async (req, res) => {
  try {
    const { title, artist, album, genre, rightsConfirmed } = req.body;

    if (!title || !artist) {
      return res.status(400).json({ message: "Title and artist are required" });
    }
    if (rightsConfirmed !== "true" && rightsConfirmed !== true) {
      return res
        .status(400)
        .json({ message: "You must confirm you have the right to distribute this song" });
    }
    if (!req.files || !req.files.audio || !req.files.cover) {
      return res.status(400).json({ message: "Both an audio file and a cover image are required" });
    }

    const audioFile = toPublicPath("songs", req.files.audio[0].filename);
    const coverImage = toPublicPath("covers", req.files.cover[0].filename);

    const song = await prisma.song.create({
      data: {
        title,
        artist,
        album: album || "",
        genre: genre || "",
        audioFile,
        coverImage,
        rightsConfirmed: true,
      },
    });

    res.status(201).json({ song: withId(song) });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

// PUT /api/songs/:id (admin only)
exports.updateSong = async (req, res) => {
  try {
    const id = parseId(req.params.id);
    if (id === null) return res.status(404).json({ message: "Song not found" });

    const existing = await prisma.song.findUnique({ where: { id } });
    if (!existing) return res.status(404).json({ message: "Song not found" });

    const { title, artist, album, genre } = req.body;
    const data = {};
    if (title) data.title = title;
    if (artist) data.artist = artist;
    if (album !== undefined) data.album = album;
    if (genre !== undefined) data.genre = genre;

    // Optional file replacements
    if (req.files && req.files.audio) {
      deleteUploadedFile(existing.audioFile);
      data.audioFile = toPublicPath("songs", req.files.audio[0].filename);
    }
    if (req.files && req.files.cover) {
      deleteUploadedFile(existing.coverImage);
      data.coverImage = toPublicPath("covers", req.files.cover[0].filename);
    }

    const song = await prisma.song.update({ where: { id }, data });
    res.json({ song: withId(song) });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

// DELETE /api/songs/:id (admin only)
exports.deleteSong = async (req, res) => {
  try {
    const id = parseId(req.params.id);
    if (id === null) return res.status(404).json({ message: "Song not found" });

    const song = await prisma.song.findUnique({ where: { id } });
    if (!song) return res.status(404).json({ message: "Song not found" });

    deleteUploadedFile(song.audioFile);
    deleteUploadedFile(song.coverImage);
    await prisma.song.delete({ where: { id } });

    res.json({ message: "Song deleted" });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

// GET /api/songs/:id/download
exports.downloadSong = async (req, res) => {
  try {
    const id = parseId(req.params.id);
    if (id === null) return res.status(404).json({ message: "Song not found" });

    const song = await prisma.song.findUnique({ where: { id } });
    if (!song) return res.status(404).json({ message: "Song not found" });

    const filePath = path.join(__dirname, "..", song.audioFile);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "Audio file missing on server" });
    }

    prisma.song.update({ where: { id }, data: { downloads: { increment: 1 } } }).catch(() => {});

    const filename = `${song.artist} - ${song.title}${path.extname(filePath)}`;
    res.download(filePath, filename);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

function deleteUploadedFile(publicPath) {
  try {
    const filePath = path.join(__dirname, "..", publicPath);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  } catch (err) {
    console.warn("Could not delete file:", publicPath, err.message);
  }
}
