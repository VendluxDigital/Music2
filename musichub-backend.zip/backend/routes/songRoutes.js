const express = require("express");
const router = express.Router();
const protect = require("../middleware/auth");
const upload = require("../middleware/upload");
const {
  getAllSongs,
  getLatestSongs,
  getTrendingSongs,
  searchSongs,
  getSongById,
  createSong,
  updateSong,
  deleteSong,
  downloadSong,
} = require("../controllers/songController");

const uploadFields = upload.fields([
  { name: "audio", maxCount: 1 },
  { name: "cover", maxCount: 1 },
]);

// Public routes
router.get("/", getAllSongs);
router.get("/latest", getLatestSongs);
router.get("/trending", getTrendingSongs);
router.get("/search", searchSongs);
router.get("/:id/download", downloadSong);
router.get("/:id", getSongById);

// Admin-only routes
router.post("/", protect, uploadFields, createSong);
router.put("/:id", protect, uploadFields, updateSong);
router.delete("/:id", protect, deleteSong);

module.exports = router;
