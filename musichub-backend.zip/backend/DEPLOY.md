# Deploying this backend to Render

1. Push this `backend` folder to a GitHub repo, or use the Render CLI /
   Docker option if you'd rather skip Git.
2. On render.com: **New +** → **Web Service** → connect the repo.
   - Root Directory: `backend` (leave blank if this folder is the repo root)
   - Build command: `npm install`
   - Start command: `npm start`
3. Add environment variables in Render's dashboard:
   - `DATABASE_URL` — your Neon Postgres connection string
   - `JWT_SECRET` — any long random string
   - `JWT_EXPIRES_IN` — `7d`
   - `ADMIN_USERNAME`, `ADMIN_PASSWORD` — your admin login
4. Deploy. Render gives you a URL like `https://musichub-backend.onrender.com`.
5. Before (or after) first deploy, run these locally against the same
   `DATABASE_URL` to set up the database:
   ```bash
   cp .env.example .env   # fill in real values
   npm install
   npx prisma db push     # creates the tables
   node scripts/createAdmin.js
   ```

Note: Render's free tier has an ephemeral filesystem — uploaded song/cover
files can be lost on redeploy or after long inactivity. Fine for a demo;
swap in S3/Cloudinary for persistent production storage later.

Once live, give the frontend's `VITE_API_URL` this backend's URL + `/api`
(e.g. `https://musichub-backend.onrender.com/api`).
